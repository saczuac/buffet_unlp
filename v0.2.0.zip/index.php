<?php

ini_set('display_startup_errors',1);
ini_set('display_errors',1);
error_reporting(-1);

require 'vendor/autoload.php';

use App\Entity\User;
use Psr\Http\Message\ServerRequestInterface;
use Psr\Http\Message\ResponseInterface;
use App\Controller\HomeController;
use App\Controller\AlumnoController;

$userResource = new \App\Resource\UserResource();
$alumnoResource = new \App\Resource\AlumnoResource();
$cuotasResource = new \App\Resource\CuotasResource();

$app = new \Slim\Slim(array(
	'view' => new \Slim\Views\Twig()
));

$view = $app->view();
$view->parserOptions = array(
	'debug' => true
);


$homeController = new HomeController($app->view);
$alumnoController = new AlumnoController($app->view, $alumnoResource);

$app->get('/', function () use ($app, $homeController) {
    echo $homeController->index($app->request);
});

$app->get('/users(/(:id)(/))', function($id = null) use ($userResource) {
   echo "";
});

$app->group('/alumnos', function() use ($app, $alumnoController) {

	$app->get('/', function() use($app, $alumnoController){
		echo $alumnoController->index($app->request);
	});

	$app->get('/new', function() use ($app, $alumnoController){
		echo $alumnoController->_new_($app->request);
	});

	$app->post('/new', function() use ($app, $alumnoController){
		echo $alumnoController->create($app);
	});

	$app->get('/:id', function($id) use ($app, $alumnoController) {
	    echo $alumnoController->show($id);
	});

	$app->delete('/:id', function($id) use ($app, $alumnoController){
		echo $alumnoController->delete($app, $id);
	});

	$app->get('/:id/edit', function($id) use ($app, $alumnoController){
		echo $alumnoController->edit($id);
	});

	$app->put('/:id/edit', function($id) use ($app, $alumnoController){
		echo $alumnoController->update($app->request, $id);
	});
});

$app->get('/cuotas', function() use($app, $cuotasResource){
	echo $app->view->render(
		"cuotas/index.twig", 
		array('cuotas' => ($cuotasResource->get()))
	);
});

$app->get('/cuotas(/show((:id)(/)))', function($id) use ($app, $cuotasResource) {
    echo $app->view->render(
		"cuotas/show.twig", 
		array('cuota' => ($cuotasResource->get($id)))
	);
});

$app->get('/cuotas(/editar(/(:id)(/)))', function($id) use ($app, $cuotasResource) {
    echo $app->view->render(
		"cuotas/edit.twig", 
		array('cuota' => ($cuotasResource->get($id)))
	);
});

$app->post('/cuotas(/editar(/(:id)(/)))', function($id) use ($app, $cuotasResource) {
    $cuotasResource->edit($id,
			$app->request->post('numero'),
					$app->request->post('monto'),
					$app->request->post('tipo'),
					$app->request->post('comco'));
			$app->redirect('/cuotas');
		
});

$app->get('/cuotas(/insert)', function() use($app, $cuotasResource){
	echo $app->view->render(
		"cuotas/insert.twig", 
		array()
	);
});

$app->post('/cuotas(/insert)', function() use($app, $cuotasResource){
	$cuotasResource->insert($app->request->post('anio'),
					$app->request->post('mes'),
					$app->request->post('numero'),
					$app->request->post('monto'),
					$app->request->post('tipo'),
					$app->request->post('comco'));
	$app->redirect('/cuotas');
});


$app->get('/cuotas(/eliminar(/(:id)(/)))', function($id) use ($app, $cuotasResource) {
    $cuotasResource->delete($id);
    		$app->redirect('/cuotas');
			/*echo $app->view->render(
		"cuotas/index.twig", 
		array('cuotas' => ($cuotasResource->get())));*/
		
});

$app->run();