<?php 

namespace App\Controller;

use App\Controller\AbstractController;

class AlumnoController extends AbstractController
{

	public function index($request = null) {
		$alumnos = $this->getResource()->get();
		return $this->getView()->render(
			'alumnos/index.twig', 
				array('alumnos' => $alumnos)
		);
	}

	public function show($id) {
		$alumno = $this->getResource()->get($id);
		return $this->getView()->render(
			'/alumnos/show.twig', 
			array('alumno' => $alumno)
		);
	}

	public function _new_() {
		return $this->getView()->render(
			'alumnos/new.twig'
		);
	}

	public function create($app) {
		$alumno = $this->getResource()->save($app->request);
		return $app->redirect('/alumnos/' . $alumno->getId());
	}

	public function edit($id) {
		$alumno = $this->getResource()->get($id);
		return $this->getView()->render(
			'alumnos/edit.twig',
			array('alumno' => $alumno)
		);
	}

	public function update($request, $id) {
		$alumno = $this->getResource()->save($request, $id);

	}

	public function delete($app, $id) {
		$alumno = $this->getResource()->delete($id);
		return $app->redirect('/alumnos');
	}
}

 ?>