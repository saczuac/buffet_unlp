<?php
namespace App\Entity;

use App\Entity;
use Doctrine\ORM\Mapping;

/**
 *
 * @Entity
 * @Table(name="usuario")
 */
class User
{
    /**
     * @var integer
     *
     * @Id
     * @Column(name="id_", type="integer")
     * @GeneratedValue(strategy="AUTO")
     */
    protected $id;

    /**
     * @ManyToOne(targetEntity="Rol", inversedBy="id")
     * @JoinColumn(name="id_rol", referencedColumnName="id")
     **/
    protected $rol;

    /**
     * @var string
     * @Column(type="string", length=64)
     */
    protected $name;

    /**
     * @var string
     * @Column(type="string", length=255)
     */
    protected $email;

    // Define setters/getters for all properties...

    public function getId() {
    	return $this->id;
    }

    public function getName() {
    	return $this->name;
    }

    public function setName($name) {
    	$this->name = $name;

    	return $this;
    }

    public function getEmail() {
    	return $this->email;
    }

    public function setEmail($email) {
    	$this->email = $email;

    	return $this;
    }
}

 ?>