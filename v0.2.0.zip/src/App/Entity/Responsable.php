<?php 
namespace App\Entity;

use App\Entity;
use Doctrine\ORM\Mapping;

/**
 *
 * @Entity
 * @Table(name="responsable")
 */
class Responsable {
	/**
     * @var integer
     *
     * @Id
     * @Column(name="id", type="integer")
     * @GeneratedValue(strategy="AUTO")
     */
    protected $id;

    /**
     * @ManyToMany(targetEntity="Alumno", mappedBy="responsables")
     **/
    protected $alumnos;

    /**
     * @var string
     * @Column(type="string", length=25)
     */
	protected $tipo;

	/**
     * @JoinColumn(name="id_usuario", referencedColumnName="id")
     **/
	protected $nombre_usuario;

    /**
     * @var string
     * @Column(type="string", length=64)
     */
    protected $nombre;

    /**
     * @var string
     * @Column(type="string", length=45)
     */
	protected $apellido;

	/**
     * @var date
     * @Column(type="date")
     */
	protected $fecha_nacimiento;

	/**
     * @var string
     * @Column(type="string", length=45)
     */
	protected $sexo;

	/**
     * @var string
     * @Column(type="string", length=50)
     */
	protected $direccion;

	/**
     * @var string
     * @Column(type="string", length=45)
     */
	protected $mail;

	/**
     * @var integer
     * @Column(type="integer", length=45)
     */
	protected $telefono;

	// TODO: definir getters y setters
}

?>