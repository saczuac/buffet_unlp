<?php 

namespace App\Resource;

use App\Resource\AbstractResource;
use App\Entity\Alumno;

/**
 * Class Resource
 * @package App
 */
class AlumnoResource extends AbstractResource
{
	public function get($id = null)
    {
        if ($id === null) {
            $alumnos = $this->getEntityManager()->getRepository('App\Entity\Alumno')->findAll();
        } else {
            $alumnos = $this->getEntityManager()->find('App\Entity\Alumno', $id);
        }

        // @TODO handle correct status when no data is found...

        return $alumnos;
    }

    private function assign_params($request, $alumno) {
        $today = new \DateTime("now");

        $alumno->setTipoDocumento($request->params('tipo_documento'));
        $alumno->setNumeroDocumento($request->params('numero_documento'));
        $alumno->setApellido($request->params('apellido'));
        $alumno->setNombre($request->params('nombre'));
        $alumno->setFechaNacimiento(
            new \DateTime('fecha_nacimiento')
        );
        $alumno->setSexo('Masculino');
        $alumno->setFechaIngreso(
            new \DateTime('fecha_ingreso')
        );
        $alumno->setFechaAlta($today);
        $alumno->setFechaEgreso(
            new \DateTime($request->params('fecha_egreso'))
        );
        $alumno->setDireccion($request->params('direccion'));
    }

    public function save($request, $id = null) {

        if(empty($id)) {
            $alumno = new Alumno();
        } else {
            $alumno = $this->get($id);
        }
        $alumno = new Alumno();
       
        $this->assign_params($request, $alumno);
        
        try {
            $this->getEntityManager()->persist($alumno);
            $this->getEntityManager()->flush();
            return true;
        }
        catch(Exception $e) {
            return false;
        }
        return true;
    }

    public function delete($id) {
        $alumno = $this->getEntityManager()->find('App\Entity\Alumno', $id);
        $this->getEntityManager()->remove($alumno);
        $this->getEntityManager()->flush();
        return true;
    }
    
}

 ?>