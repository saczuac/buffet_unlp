Archivo README para repositorio, grupo 38 Proyecto de Software 2015

Correr el siguiente comando para crear la base de datos:

$~ vendor/bin/doctrine orm:schema-tool:create

O en caso de ya existir la base de datos: 

$~ vendor/bin/doctrine orm:schema-tool:update
