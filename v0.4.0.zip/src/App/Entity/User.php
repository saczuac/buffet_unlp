<?php
namespace App\Entity;

use App\Entity;
use Doctrine\ORM\Mapping;

/**
 *
 * @Entity
 * @Table(name="usuario")
 */
class User
{
    /**
     * @var string
     *
     * @Id
     * @Column(name="username", type="string")
     */
    protected $id;
   /**
     * @var string
     * @Column(type="string", length=16)
     */
    protected $password;
    /**
     * @var integer
     * @Column(type="integer")
     */
    protected $idRol;
    /**
     * @var integer
     * @Column(type="integer")
     */
    protected $habilitado;

    /**
     * @OneToOne(targetEntity="Responsable", cascade={"merge"})
     * @JoinColumn(name="responsable_id", referencedColumnName="id", nullable=true)
     **/
    protected $responsable;

    /**
     * @var string
     * @Column(type="string", length=64)
     */
    protected $name;
    /**
     * @var string
     * @Column(type="string", length=255)
     */
    protected $email;
    protected $nameRol;
    // Define setters/getters for all properties...

    public function getId() {
    	return $this->id;
    }
    public function getUsername() {
    	return $this->id;
    }
    public function getPassword() {
        return $this->password;
    }
    public function getIdRol() {
        return $this->idRol;
    }
    public function getHabilitado() {
        return $this->habilitado;
    }    
    public function getName() {
        return $this->name;
    }
    public function getEmail() {
        return $this->email;
    }
    public function getNameRol() {
        $aux='';
        switch ($this->idRol) {
           case 1:
                 $aux='consulta';
                 break;
           case 2:
                 $aux='administracion';
                 break;
            case 3:
                 $aux='gestion';
                 break;
        }   
        return $aux;
    }
    public function setId($id) {
        $this->id = $id;
        return $this;
    }
    public function setUsername($username) {
        $this->id = $username;
        return $this;  
    }
    public function setPassword($password) {
        $this->password = $password;
        return $this; 
    }
    public function setRol($rol) {
        $this->idRol = $rol;
        return $this;
    }
    public function setHabilitado($habilitado) {
        $this->habilitado = $habilitado;
        return $this;
    }
    public function setName($name) {
    	$this->name = $name;
    	return $this;
    }
    public function setEmail($email) {
    	$this->email = $email;
    	return $this;
    }

    public function getResponsable() {
        return $this->responsable;
    }

    public function asignarResponsable($responsable) {
        $this->responsable = $responsable;
        return $this;
    }

    public function desasignarResponsable() {
        $this->responsable = null;
        return $this;
    }
}

 ?>