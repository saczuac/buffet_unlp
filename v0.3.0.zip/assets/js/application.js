$(document).ready(function(){
	$("input[type=datepicker]").datepicker(
		{
			dateFormat: "dd-mm-yy",
			changeYear: true,
			yearRange: "1950:"
		}
	);

	$("#delete").on("click", function(event){
		if(!(confirm("¿Esta seguro que quiere eliminar?"))) {
			event.preventDefault();
		}
	});

	$(".flash").on('click', function(){
		$(this).fadeOut("slow");
	});

	$(".flash").delay(5000).fadeOut("slow");

	$("#collapse").mouseover(function(){
		$('.collapsible-nav').fadeIn(250);
	});

	$(".collapsible-nav").mouseleave(function(){
		$(this).fadeOut(250);
	});
});