<?php 

namespace App\Controller;

abstract class AbstractController
{

	private $resource;

	private $view;

	public function __construct($view, $resource = null) {
		$this->setView($view);
		$this->setResource($resource);
		return $this;
	}

	public function getView() {
		return $this->view;
	}

	public function setView($view) {
		$this->view = $view;
	}

	public function getResource() {
		return $this->resource;
	}

	public function setResource($resource) {
		$this->resource = $resource;
	}
}

 ?>