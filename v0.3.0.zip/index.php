<?php
session_start();

require_once 'src/helpers/debug_options.php';

require 'vendor/autoload.php';

use App\Entity\User;
use Psr\Http\Message\ServerRequestInterface;
use Psr\Http\Message\ResponseInterface;
use App\Controller\HomeController;
use App\Controller\AlumnoController;
use App\Controller\ResponsableController;
use App\Controller\PagoController;
use App\Controller\ListadoController;

$userResource = new \App\Resource\UserResource();
$alumnoResource = new \App\Resource\AlumnoResource();
$cuotasResource = new \App\Resource\CuotasResource();
$responsableResource = new \App\Resource\ResponsableResource();
$pagoResource = new \App\Resource\PagoResource();
$configuracionResource = new \App\Resource\ConfiguracionResource();
$parrafoResource = new \App\Resource\ParrafoResource();

$app = new \Slim\Slim(array(
	'view' => new \Slim\Views\Twig()
));

$view = $app->view();
$view->parserOptions = array(
	'debug' => true
);

$view->parserExtensions = array(
	new \Twig_Extension_Debug(),
    new \Slim\Views\TwigExtension()
);

$view->getEnvironment()->addGlobal('session', $_SESSION);
$view->getEnvironment()->addGlobal('server', $_SERVER);


$homeController = new HomeController($app->view);
$alumnoController = new AlumnoController($app->view, $alumnoResource);
$responsableController = new ResponsableController($app->view, $responsableResource);
$pagoController = new PagoController($app->view, $pagoResource);
$listadoController = new ListadoController($app->view);

$app->get('/', function () use ($app, $homeController) {
    echo $homeController->index($app->request);
});

require_once 'src/helpers/permission_filters.php';

$app->get('/mensaje', function () use ($app) {
    echo $app->view->render("mensaje.twig",array('msj' => "No tiene permisos para esta seccion "));
});
//fin befores

$app->get('/', function () use ($app, $configuracionResource,$parrafoResource) {
    echo $app->view->render("home.twig", array('sitio' => ($configuracionResource->get(1)),'parrafo' => ($parrafoResource->get())));
});

$app->group('/listados', function() use($app, $listadoController){
	$app->get('/matriculados', function() use ($listadoController) {
		echo $listadoController->matriculasPagas();
	});

	$app->get('/cuotas_pagas', function() use ($listadoController) {
		echo $listadoController->cuotasPagas();
	});

	$app->get('/cuotas_inpagas', function() use ($listadoController) {
		print_r($listadoController->cuotasInpagas());
	});
});

$app->group('/pagos', function() use($app, $pagoController){
	
	$app->get('/', function() use($app, $pagoController){
		print_r ($pagoController->index());
	});

	$app->get('/:id', function($id_alumno) use($app, $pagoController){
		echo $pagoController->pagos($app, $id_alumno);
	});

	$app->post('/:id', function($id_alumno) use ($app, $pagoController) {
		echo $pagoController->create($app, $id_alumno);
	});
});

$app->group('/alumnos', function() use ($app, $alumnoController, $responsableController) {

	$app->get('/', function() use($app, $alumnoController){
		echo $alumnoController->index($app->request);
	});

	$app->get('/new', function() use ($app, $alumnoController){
		echo $alumnoController->_new_($app->request);
	});

	$app->post('/new', function() use ($app, $alumnoController){
		echo $alumnoController->create($app);
	});

	$app->get('/:id', function($id) use ($app, $alumnoController) {
	    echo $alumnoController->show($id);
	});

	$app->delete('/:id', function($id) use ($app, $alumnoController){
		echo $alumnoController->delete($app, $id);
	});

	$app->get('/:id/delete', function($id) use ($app, $alumnoController){
		echo $alumnoController->delete($app, $id);
	});

	$app->get('/:id/edit', function($id) use ($app, $alumnoController){
		echo $alumnoController->edit($id);
	});

	$app->put('/:id/edit', function($id) use ($app, $alumnoController){
		echo $alumnoController->update($app, $id);
	});

	$app->get('/:id/responsables/new', function($id) use ($app, $responsableController) {
		echo $responsableController->_new_($id);
	});

	$app->post('/:id/responsables/new', function($id) use ($app, $responsableController) {
		echo $responsableController->create($app, $id);
	});

	$app->get('/:id/responsables/select', function($id) use ($app, $responsableController) {
		echo $responsableController->select($app, $id);
	});

	$app->post('/:id/responsables/select', function($id) use ($app, $responsableController) {
		echo $responsableController->assign($app, $id);
	});

	$app->get('/:id/responsables/:id_responsable', function($id, $id_responsable) use ($app, $responsableController) {
		echo $responsableController->show($id_responsable);
	});

	$app->get('/:id/responsables/:responsable/detach', function($id_alumno, $id_responsable) use ($app, $responsableController){
		print_r($responsableController->detach($app, $id_responsable, $id_alumno));
	});

	$app->get('/:id/responsables/:responsable/edit', function($id, $id_responsable) use ($app, $responsableController){
		echo $responsableController->edit($app, $id_responsable);
	});

	$app->put('/:id/responsables/:id_responsable/edit', function($id, $id_responsable) use ($app, $responsableController){
		echo $responsableController->update($app, $id_responsable, $id);
	});
});

// Ruta para Cuotas#index
$app->group('/cuotas', function() use ($app, $cuotasResource) {

		$app->get('/', function() use($app, $cuotasResource){
			$app->applyHook('must.be.administracion-gestion');
			echo $app->view->render(
				"cuotas/index.twig", 
				array('cuotas' => ($cuotasResource->get()))
			);
		});

		$app->get('/show(/(:id)(/))', function($id) use ($app, $cuotasResource) {
			$app->applyHook('must.be.administracion-gestion');
		    echo $app->view->render(
				"cuotas/show.twig", 
				array('cuota' => ($cuotasResource->get($id)))
			);
		});

		$app->get('/editar(/(:id)(/))', function($id) use ($app, $cuotasResource) {
			$app->applyHook('must.be.administracion-gestion');
		    echo $app->view->render(
				"cuotas/edit.twig", 
				array('cuota' => ($cuotasResource->get($id)))
			);
		});

		$app->post('/editar(/(:id)(/))', function($id) use ($app, $cuotasResource) {
			$app->applyHook('must.be.administracion-gestion');
		    $cuotasResource->edit($id,
					$app->request->post('numero'),
							$app->request->post('monto'),
							$app->request->post('tipo'),
							$app->request->post('comco'));
					$app->redirect('/cuotas');
				
		});

		$app->get('/insert', function() use($app, $cuotasResource){
			$app->applyHook('must.be.administracion-gestion');
			echo $app->view->render(
				"cuotas/insert.twig", 
				array()
			);
		});

		$app->post('/insert', function() use($app, $cuotasResource){
			$app->applyHook('must.be.administracion-gestion');			
			$cuotasResource->insert($app->request->post('anio'),
							$app->request->post('mes'),
							$app->request->post('numero'),
							$app->request->post('monto'),
							$app->request->post('tipo'),
							$app->request->post('comco'));
			$app->redirect('/cuotas');
		});

		$app->get('/eliminar(/(:id)(/))', function($id) use ($app, $cuotasResource) {
			$app->applyHook('must.be.administracion-gestion');
		    $cuotasResource->delete($id);
		    		$app->redirect('/cuotas');
					/*echo $app->view->render(
				"cuotas/index.twig", 
				array('cuotas' => ($cuotasResource->get())));*/
				
		});

});

$app->group('/usuarios', function() use ($app, $userResource, $responsableResource) {

		$app->put('/', function() use ($app, $userResource){
			$app->applyHook('must.be.administracion');
			if ($userResource->asignar($app->request)) {
				$app->flash('success', 'El responsable ha sido asignado correctamente.');
			} else {
				$app->flash('error', 'El usuario ya tiene un responsable asignado.');
			}
			header("Refresh:0");
		});

		$app->delete('/', function() use($app, $userResource){
			$app->applyHook('must.be.administracion');
			$userResource->desasignar($app->request->delete('id_usuario'));
			$app->flash('success', 'El responsable a sido desasignado exitosamente.');
			header("Refresh:0");

		});
		
		$app->get('/', function() use($app, $userResource, $responsableResource) {
			$app->applyHook('must.be.administracion');

			$responsables = $responsableResource->get();
			echo $app->view->render(
				"usuarios/index.twig", 
				array(
					'usuarios' => ($userResource->get()),
					'responsables' => $responsables
				)
			);
		});
		$app->get('/editar(/(:id)(/))', function($id) use ($app, $userResource) {
		    $app->applyHook('must.be.administracion');
		    echo $app->view->render(
				"usuarios/edit.twig", 
				array('usuario' => ($userResource->get($id)))
			);
		});
		$app->post('/editar(/(:id)(/))', function($id) use ($app, $userResource) {
		    $app->applyHook('must.be.administracion');
		    $userResource->edit($id,
					$app->request->post('name'),
					$app->request->post('habilitado'),
					$app->request->post('email'),
					$app->request->post('rol'));
					$app->redirect('/usuarios');
				
		});
		$app->get('/insert', function() use($app, $userResource){
			$app->applyHook('must.be.administracion');
			echo $app->view->render(
				"usuarios/insert.twig", 
				array()
			);
		});

		$app->post('/insert', function() use($app, $userResource){
			$app->applyHook('must.be.administracion');
			$userResource->insert($app->request->post('user'),
							$app->request->post('pass'),
							$app->request->post('name'),
							$app->request->post('rol'),
							$app->request->post('email'));
			$app->redirect('/usuarios');
		});
		$app->get('/eliminar(/(:id)(/))', function($id) use ($app, $userResource) {
			$app->applyHook('must.be.administracion');
		    $userResource->delete($id);
		    		$app->redirect('/usuarios');
					/*echo $app->view->render(
				"cuotas/index.twig", 
				array('cuotas' => ($cuotasResource->get())));*/
				
		});
		$app->get('/show(/(:id)(/))', function($id) use ($app, $userResource) {
			$app->applyHook('must.be.administracion');
		    echo $app->view->render(
				"usuarios/show.twig", 
				array('usuario' => ($userResource->get($id)))
			);
		});
		$app->get('/habilitar(/(:id)(/))', function($id) use ($app, $userResource) {
			$app->applyHook('must.be.administracion');
		    $userResource->habilitar($id);
		    $app->redirect('/usuarios');
		});
		$app->get('/deshabilitar(/(:id)(/))', function($id) use ($app, $userResource) {
			$app->applyHook('must.be.administracion');
		    $userResource->deshabilitar($id);
		    $app->redirect('/usuarios');
		});
});
	
$app->post('/login', function() use ($app, $userResource) {
    if (($userResource->login($app->request->post('name'),$app->request->post('password'))) != false) {
    	$user=$userResource->login($app->request->post('name'),$app->request->post('password'));
    	$_SESSION['user']=$user->getUsername();
    	$_SESSION['rol']=$user->getIdRol();
    	$app->view->getEnvironment()->addGlobal('session',$_SESSION);
    	$rootUri = $app->request->getResourceUri();
    	$app->redirect('/');
    }else{
		echo $app->view->render("login.twig");}
});

$app->get('/logout', function() use ($app, $userResource) {
    session_destroy();
    $app->view->getEnvironment()->addGlobal('session',$_SESSION);
    $app->redirect('/');
});

$app->group('/configuracion', function() use ($app, $configuracionResource,$parrafoResource) {
	
	$app->get('/', function() use ($app, $configuracionResource,$parrafoResource) {
			$app->applyHook('must.be.administracion');
		    echo $app->view->render("configuracion/index.twig",array('configuracion' => ($configuracionResource->get()),'parrafo' => ($parrafoResource->get())));
		});
	$app->post('/', function() use ($app, $configuracionResource) {
		    $app->applyHook('must.be.administracion');
		    $configuracionResource->edit(
					$app->request->post('titulo'),
					$app->request->post('contenido'),
					$app->request->post('email'),
					$app->request->post('habilitado'),
					$app->request->post('paginacion'));
					$app->redirect('/configuracion');
				
		});
			$app->get('/habilitar', function() use ($app, $configuracionResource) {
			$app->applyHook('must.be.administracion');
		    $configuracionResource->habilitar(1);
		    $app->redirect('/configuracion');
		});
		$app->post('/deshabilitar', function() use ($app, $configuracionResource) {
			$app->applyHook('must.be.administracion');
		    $configuracionResource->deshabilitar(1,$app->request->post('mensaje'));
		    $app->redirect('/configuracion');
		});
	});

$app->group('/parrafo', function() use ($app,$parrafoResource) {
	$app->get('/editar(/(:id)(/))', function($id) use ($app, $parrafoResource) {
	    $app->applyHook('must.be.administracion');
	    echo $app->view->render("configuracion/edit.twig", 	array('parr' => ($parrafoResource->get($id)))
		);
	});
	$app->post('/editar(/(:id)(/))', function($id) use ($app, $parrafoResource) {
	    $app->applyHook('must.be.administracion');
	    $parrafoResource->edit($id,$app->request->post('contenido'));
		$app->redirect('/configuracion');
			
	});
	$app->get('/insert', function() use($app, $parrafoResource){
		$app->applyHook('must.be.administracion-gestion');
		echo $app->view->render(
			"configuracion/insert.twig", 
			array()
		);
	});

	$app->post('/insert', function() use($app, $parrafoResource){
		$app->applyHook('must.be.administracion-gestion');
		$parrafoResource->insert($app->request->post('parrafo'));
		$app->redirect('/configuracion');
	});
	$app->get('/eliminar(/(:id)(/))', function($id) use ($app, $parrafoResource) {
		$app->applyHook('must.be.administracion');
	    $parrafoResource->delete($id);
	    		$app->redirect('/configuracion');
				/*echo $app->view->render(
			"cuotas/index.twig", 
			array('cuotas' => ($cuotasResource->get())));*/
			
	});
});

$app->run();
