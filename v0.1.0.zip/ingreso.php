<?php include('includes/header.php'); ?>

<form action="alert('Alumno agregado')">
	<div class="style-5">
		First name: <input type="text" name="fname" required><br>
		Número de Documento <input type="text" name="fname" required><br>
		Apellido y Nombre <input type="text" name="fname" required><br>
		Fecha de Nacimiento <input type="text" name="fname" required><br>
		Sexo <ul><li> <input type="radio" checked="checked" value="male" name="gender" required> Masculino<br></li>
  					<li><input type="radio" value="female" name="gender"> Femenino<br></ul></li>
		Apellido y Nombre del tutor legal <input type="text" name="fname" required><br>
		Tipo de parentesco del tutor legal <input type="text" name="fname" required><br>
		Apellido y Nombre del padre <input type="text" name="fname"><br>
		Apellido y Nombre de la madre <input type="text" name="fname"><br>
		Mail de contacto <input type="text" name="fname"><br>
		Teléfono de contacto <input type="text" name="fname" required><br>
		Dirección <input type="text" name="fname" required><br>
		Fecha de Alta en el sistema <input type="text" name="fname" required><br>
		<button type="submit">Agregar!</button>

	</div>

	</form>

</html>
