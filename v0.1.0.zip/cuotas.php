<?php include('includes/header.php'); ?>

<div class="container">

	<div class="main-header">
		<span class="icon">
			<i class="fa fa-list fa-lg"></i>
		</span>
		<h2 class="title">Administración de Cuotas y Becas</h1>
		<div class="nav-listado">
			<ul>
				<li><a href="#cuotas">Cuotas</a></li>
				<li><a href="#deudas">Deudas</a></li>
				<li><a href="#becas">Becas</a></li>
			</ul>
		</div>
	</div>

	<div class="container listado col col-3">
		<a name="cuotas"></a>
		<div class="listado-header">
			<h2 class="listado-title">Cuotas</h2>
			<button class="btn right">
				<i class="fa fa-plus-circle fa-lg"></i><a href="#">Nuevo Pago</a>
			</button>
		</div>
		<table>
			<thead class="table-header">
				<tr>
					<th>Mes</th>
					<th>Año</th>
					<th>Matricula/Comisi&oacute;n</th>
					<th>Acciones</th>
				</tr>
			</thead>
			<tbody>
				<tr class="table-data-row">
					<td>07</td>
					<td>2014</td>
					<td><a href="alumno.php">302103</a></td>
					<td>
						<a href="#"><i class="fa fa-pencil"></i></a>
						<a href=""><i class="fa fa-trash-o"></i></a>
					</td>
				</tr>
				<tr class="table-data-row">
					<td>08</td>
					<td>2014</td>
					<td><a href="alumno.php">302103</a></td>
					<td>
						<a href="#"><i class="fa fa-pencil"></i></a>
						<a href=""><i class="fa fa-trash-o"></i></a>
					</td>
				</tr>
				<tr class="table-data-row">
					<td>09</td>
					<td>2014</td>
					<td><a href="alumno.php">302103</a></td>
					<td>
						<a href="#"><i class="fa fa-pencil"></i></a>
						<a href=""><i class="fa fa-trash-o"></i></a>
					</td>
				</tr>
				<tr class="table-data-row">
					<td>10</td>
					<td>2014</td>
					<td><a href="alumno.php">302103</a></td>
					<td>
						<a href="#"><i class="fa fa-pencil"></i></a>
						<a href=""><i class="fa fa-trash-o"></i></a>
					</td>
				</tr>
				<tr class="table-data-row">
					<td>11</td>
					<td>2014</td>
					<td><a href="alumno.php">302103</a></td>
					<td>
						<a href="#"><i class="fa fa-pencil"></i></a>
						<a href=""><i class="fa fa-trash-o"></i></a>
					</td>
				</tr>
			</tbody>
		</table>
	</div>

	<div class="container listado col col-3">
		<a name="deudas"></a>
		<div class="listado-header">
			<h2 class="listado-title">Deudas</h2>
			<button class="btn right">
				<i class="fa fa-plus-circle fa-lg"></i><a href="#">Pagar Deuda</a>
			</button>
		</div>
		<table>
			<thead class="table-header">
				<tr>
					<th>Mes</th>
					<th>Año</th>
					<th>Nombre</th>
					<th>Apellido</th>
					<th>Acciones</th>
				</tr>
			</thead>
			<tbody>
				<tr class="table-data-row">
					<td>12</td>
					<td>2014</td>
					<td>Santiago</td>
					<td>Figueiras</td>
					<td>
						<a href="#"><i class="fa fa-pencil"></i></a>
						<a href=""><i class="fa fa-trash-o"></i></a>
					</td>
				</tr>
				<tr class="table-data-row">
					<td>01</td>
					<td>2015</td>
					<td>Santiago</td>
					<td>Figueiras</td>
					<td>
						<a href="#"><i class="fa fa-pencil"></i></a>
						<a href=""><i class="fa fa-trash-o"></i></a>
					</td>
				</tr>
				<tr class="table-data-row">
					<td>02</td>
					<td>2015</td>
					<td>Santiago</td>
					<td>Figueiras</td>
					<td>
						<a href="#"><i class="fa fa-pencil"></i></a>
						<a href=""><i class="fa fa-trash-o"></i></a>
					</td>
				</tr>
			</tbody>
		</table>
	</div>

	<div class="container listado col col-3">
		<a name="becas"></a>
		<div class="listado-header">
			<h2 class="listado-title">Becas</h2>
			<button class="btn right">
				<i class="fa fa-plus-circle fa-lg"></i><a href="#">Nueva Beca</a>
			</button>
		</div>
	</div>

