<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Cooperadora Escuela Primaria Anexa</title>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css">
	<link href='https://fonts.googleapis.com/css?family=Raleway:400,700' rel='stylesheet' type='text/css'>
	<link rel="stylesheet" href="css/style.css">
	<link rel="stylesheet" href="css/responsive.css">
</head>
<body>
	<header>
		<nav>
			<div class="nav acciones">
				<ul>
					<li><a href="/"><img class="logo" src="img/LogoUNLP-cl.png" alt="UNLP Logo"></a></li>
					<li class="nav-left"><a href="alumnos.php">Alumnos</a></li>
					<li class="nav-left"><a href="cuotas.php">Cuotas</a></li>
					<li class="nav-right"><a href="#">Login</a></li>
					<li class="nav-right"><a href="#">Logout</a></li>
				</ul>
			</div>
		</nav>
	</header>
</body>