<?php include('includes/header.php'); ?>


<div class="style-3">
		<img src="http://www.elhistoriador.com.ar/biografias/g/gonzalez.gif"></div>
	<div class="style-4">
		<ul>
			<li> <b>Universidad Nacional de La Plata</b></li>
			<li><b>Presidente: Lic. Raúl Anibal Perdomo</b></li>
			<li><b>Vicepresidente Área Institucional: Dr. Fernando A. Tauber</b></li>
			<li><b>Vicepresidente Área Académica: Prof. Ana María Barletta</b></li>
			<li><b>Secretaria Académica: Dra. María Mercedes Medina</b></li>
			<li><b>Prosecretaria de Asuntos Académicos: Prof. Laura Agratti</b></li>	

		</ul>	
		<ul>
			<li> <b>Escuela Graduada “Joaquín V. González”</b></li>
			<li> <b>Directora:</b> Prof. Claudia Beatriz Binaghi</li>
			<li> <b>Vicedirectora:</b> Prof. Violeta N. Pesci</li>
			<li> <b>Secretaria Docente:</b> Prof. Mariela Boccia</li>
			<li> <b>Secretaria Académica de Educación Inicial:</b> Prof. Rosa Mónica Bordagaray</li>
			<li> <b>Secretaria Académica de Educación Primaria: </b>Prof. Aldana López</li>
			<li> <b>Secretaria Académica de Educación Primaria: </b>Prof. Celeste Carli</li>
			<li> <b>Regente del turno mañana: </b>Prof. Elina Rebolini</li>
			<li> <b>Regente del turno tarde: </b>Prof. Leticia Peret</li>



		</ul>	
		<p>La Escuela es una Dependencia de la Presidencia de la Universidad. Los actos resolutivos que exceden la competencia de la Dirección de la Escuela, son refrendados por el Presidente de la Universidad. Dentro de la Secretaría de Asuntos Académicos de la Universidad, la Prosecretaría asesora a la Presidencia en los temas relacionados a la enseñanza preuniversitaria.</p>


		<p>El CEMYP (Consejo de Enseñanza Media y Primaria), dependiente del Consejo Superior y supervisado por su Comisión de Enseñanza, fue creado con la finalidad de “asegurar el cumplimiento de los objetivos establecidos, estudiando, estableciendo y perfeccionando la coordinación de los ciclos primario, medio y superior en procura de la unidad del proceso educativo”.Lo preside el Presidente de la Comisión de Enseñanza del Consejo Superior y está conformado por: un profesor de la Facultad de Humanidades y Ciencias de la Educación, los Directores de los Colegios y docentes elegidos por sus pares en cada centro educativo. Las sesiones son coordinadas por la Prosecretaría de Asuntos Académicos de la U.N.L.P. La Escuela participa del gobierno de la UNLP a través de un representante docente en la Asamblea Universitaria y del Director/a, quien integra el Consejo Superior con voz y voto con un sistema rotativo de pares entre los Directores/as del Sistema de Pregrado Universitario.</p>



		<p>La Directora de la Escuela es elegida directamente por el voto secreto de los docentes. La escuela cuenta con cuatro Departamentos: Biblioteca, de Orientación Educativa, de Informática y de Multimedios. También cuenta con Coordinadores de Area, personal docente especializado en las disciplinas y su didáctica, que coordina la tarea de los docentes, a la vez que los capacita, en las diferentes áreas disciplinares, y en los distintos niveles (Coordinadores de Lengua, Matemática, Música, Plástica, Educación Física, Ciencias Sociales, Ciencias Naturales, Inglés, Francés, Tecnología Educativa y Talleres).</p>


		<p>La designación de los docentes se realiza a través de un sistema de concurso de antecedentes y oposición por el término de cuatro años, la cual puede ser prorrogada habiendo aprobado la instancia de evaluación correspondiente al finalizar cada período.
La escuela cuenta con cargos de Maestro de Grado, Maestro de Sección, Auxiliar Docente, Preceptor y Ayudante de Clases Prácticas. El resto de las funciones se rentan con horas cátedra.</p>

		<p>La escuela tiene una Asociación Cooperadora de padres. Cobra una matrícula de 100 pesos por única vez cuando los niños ingresan a la escuela y luego cuotas mensuales.</p>

</html>
