<?php include('includes/header.php'); ?>

<div class="container">
	<div class="col col-6 card">
		<h2 class="title">
			<span class="icon">
				<i class="fa fa-user"></i>
			</span>
			Santiago Figueiras
		</h2>
		<div class="student-data">
			<p><span class="field">N° Documento: </span>38865056</p>
			<p><span class="field">Fecha Nacimiento: </span>11/02/1995</p>
			<p><span class="field">Sexo: </span>Masculino</p>
			<p><span class="field">Tutor Legal: </span>N/A</p>
			<p><span class="field">Parentezo del Tutor: </span>N/A</p>
			<p><span class="field">Contacto: </span>jfigueiras@yahoo.com</p>
			<p><span class="field">Telefono: </span>471-8294</p>
			<p><span class="field">Direcci&oacute;n: </span>27 y 509</p>
			<p><span class="field">Alta: </span>20/08/2014</p>
		</div>
		<div class="right">
			<a href="#"><button class="btn"><i class="fa fa-pencil"></i>Modificar</button></a>
			<a href="#"><button class="btn btn-danger"><i class="fa fa-trash-o fa"></i>Eliminar</button></a>
		</div>
	</div>

	<div class="col col-6 card">
		<h2 class="title">
			<span class="icon">
				<i class="fa fa-money"></i>
			</span>
			Becas
		</h2>
		<p>Este alumno no tiene becas asignadas.</p>
		<div class="right">
			<button class="btn"><i class="fa fa-plus-circle"></i><a href="#">Asignar Beca</a></button>
		</div>
	</div>
</div>	