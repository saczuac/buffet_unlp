<?php include('includes/header.php'); ?>

<div class="container">

	<div class="main-header">
		<span class="icon">
			<i class="fa fa-users fa-lg"></i>
		</span>
		<h2 class="title">Listado de alumnos</h1>
		<p class="main-description">A continuaci&oacute;n se ve el listado de los alumnos que est&aacute;n actualmente en el sistema.</p>
		<button class="btn"><i class="fa fa-plus-circle fa-lg"></i><a href="#">Nuevo Alumno</a></button>
	</div>
	<div class="container listado">
		<table>
			<thead class="table-header">
				<tr>
					<th>Nombre</th>
					<th>Apellido</th>
					<th>DNI</th>
					<th>Fecha Nac.</th>
					<th>Acciones</th>
				</tr>
			</thead>
			<tbody>
				<tr class="table-data-row">
					<td><a href="alumno.php">Santiago</a></td>
					<td>Figueiras</td>
					<td>38865056</td>
					<td>11/02/1995</td>
					<td>
						<a href="#"><i class="fa fa-pencil"></i></a>
						<a href=""><i class="fa fa-trash-o"></i></a>
					</td>
				</tr>
				</tr class="table-data-row">
					<td><a href="alumno.php">Santiago</td></a>
					<td>Figueiras</td>
					<td>38865056</td>
					<td>11/02/1995</td>
					<td>
						<a href="#"><i class="fa fa-pencil"></i></a>
						<a href=""><i class="fa fa-trash-o"></i></a>
					</td>
				</tr>
				</tr class="table-data-row">
					<td><a href="alumno.php">Santiago</td></a>
					<td>Figueiras</td>
					<td>38865056</td>
					<td>11/02/1995</td>
					<td>
						<a href="#"><i class="fa fa-pencil"></i></a>
						<a href=""><i class="fa fa-trash-o"></i></a>
					</td>
				</tr>
				</tr class="table-data-row">
					<td><a href="alumno.php">Santiago</td></a>
					<td>Figueiras</td>
					<td>38865056</td>
					<td>11/02/1995</td>
					<td>
						<a href="#"><i class="fa fa-pencil"></i></a>
						<a href=""><i class="fa fa-trash-o"></i></a>
					</td>
				</tr>
				</tr class="table-data-row">
					<td><a href="alumno.php">Santiago</td></a>
					<td>Figueiras</td>
					<td>38865056</td>
					<td>11/02/1995</td>
					<td>
						<a href="#"><i class="fa fa-pencil"></i></a>
						<a href=""><i class="fa fa-trash-o"></i></a>
					</td>
				</tr>
				</tr class="table-data-row">
					<td><a href="alumno.php">Santiago</td></a>
					<td>Figueiras</td>
					<td>38865056</td>
					<td>11/02/1995</td>
					<td>
						<a href="#"><i class="fa fa-pencil"></i></a>
						<a href=""><i class="fa fa-trash-o"></i></a>
					</td>
				</tr>
				</tr class="table-data-row">
					<td><a href="alumno.php">Santiago</td></a>
					<td>Figueiras</td>
					<td>38865056</td>
					<td>11/02/1995</td>
					<td>
						<a href="#"><i class="fa fa-pencil"></i></a>
						<a href=""><i class="fa fa-trash-o"></i></a>
					</td>
				</tr>
			</tbody>
		</table>
	</div>
	<!--
	<div>
		<a href="#">Nuevo Alumno</a>
	</div>

	<div class="container">
		<ul>
			<li class="fila-alumno">
				
			</li>
			<li class="fila-alumno">
				
			</li>
			<li class="fila-alumno">
				
			</li>
			<li class="fila-alumno">
				
			</li>
			<li class="fila-alumno">
				
			</li>
		</ul>
	</div>
	-->
</div>