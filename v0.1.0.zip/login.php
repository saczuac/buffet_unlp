<?php include('includes/header.php'); ?>

	<form action="alert('LOGIN')">
	<div class="style-5">
		Nombre de usuario: <input type="text" name="fname" required><br>
		Pasword <input type="text" name="fname" required><br>
		<button type="submit">Entrar</button>

	</div>

	</form>

