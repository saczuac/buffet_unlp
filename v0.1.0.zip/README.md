Archivo README para repositorio, grupo 38 Proyecto de Software 2015
